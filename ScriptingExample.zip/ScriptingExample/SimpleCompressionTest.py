from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
session.journalOptions.setValues(replayGeometry=COORDINATE, recoverGeometry=COORDINATE)
# ========================= Setting up =========================
# execfile('SimVar.py')

MeshSize            = 0.25
DisplacementValue   = 5

# ========================= Create specimens =========================
mdb.models['Model-1'].ConstrainedSketch(name='__profile__', sheetSize=200.0)
mdb.models['Model-1'].sketches['__profile__'].ConstructionLine(point1=(0.0, 
    -100.0), point2=(0.0, 100.0))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((0.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].FixedConstraint(entity=
    mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((0.0, 0.0), 
    ))
mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(0.0, 0.0), 
    point2=(5.0, 15.0))
mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((5.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((0.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].ObliqueDimension(textPoint=(
    2.86441802978516, -2.24199295043945), value=5.0, vertex1=
    mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((5.0, 0.0), )
    , vertex2=mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((
    0.0, 0.0), ))
mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((5.0, 15.0))
mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((5.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].ObliqueDimension(textPoint=(
    7.22331237792969, 3.54982376098633), value=15.0, vertex1=
    mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((5.0, 15.0), 
    ), vertex2=mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((
    5.0, 0.0), ))
mdb.models['Model-1'].Part(dimensionality=THREE_D, name='Specimen', type=
    DEFORMABLE_BODY)
mdb.models['Model-1'].parts['Specimen'].BaseSolidRevolve(angle=360.0, 
    flipRevolveDirection=OFF, sketch=
    mdb.models['Model-1'].sketches['__profile__'])
del mdb.models['Model-1'].sketches['__profile__']
mdb.models['Model-1'].ConstrainedSketch(name='__profile__', sheetSize=200.0)
mdb.models['Model-1'].sketches['__profile__'].ConstructionLine(point1=(0.0, 
    -100.0), point2=(0.0, 100.0))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((0.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].FixedConstraint(entity=
    mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((0.0, 0.0), 
    ))
mdb.models['Model-1'].sketches['__profile__'].Line(point1=(0.0, 0.0), point2=(
    7.5, 0.0))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((3.75, 0.0))
mdb.models['Model-1'].sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((3.75, 0.0), 
    ))
mdb.models['Model-1'].Part(dimensionality=THREE_D, name='Surface', type=
    DISCRETE_RIGID_SURFACE)
mdb.models['Model-1'].parts['Surface'].BaseShellRevolve(angle=360.0, 
    flipRevolveDirection=OFF, sketch=
    mdb.models['Model-1'].sketches['__profile__'])
del mdb.models['Model-1'].sketches['__profile__']

# ========================= Assign a RP =========================
mdb.models['Model-1'].parts['Surface'].ReferencePoint(point=
    mdb.models['Model-1'].parts['Surface'].vertices.findAt((0.0, 0.0, 0.0), ))

# ========================= Mesh Specimens and Surfaces =========================
mdb.models['Model-1'].parts['Surface'].PartitionFaceByShortestPath(faces=
    mdb.models['Model-1'].parts['Surface'].faces.findAt(((4.945369, 0.0, 
    -0.519779), )), point1=
    mdb.models['Model-1'].parts['Surface'].vertices.findAt((7.5, 0.0, 0.0), ), 
    point2=mdb.models['Model-1'].parts['Surface'].InterestingPoint(
    mdb.models['Model-1'].parts['Surface'].edges.findAt((0.0, 0.0, 7.5), ), 
    MIDDLE))
mdb.models['Model-1'].parts['Surface'].DatumAxisByRotation(angle=90.0, axis=
    mdb.models['Model-1'].parts['Surface'].datums[1], line=
    mdb.models['Model-1'].parts['Surface'].edges.findAt((5.625, 0.0, 0.0), ))
mdb.models['Model-1'].parts['Surface'].PartitionFaceByShortestPath(faces=
    mdb.models['Model-1'].parts['Surface'].faces.findAt(((-4.945369, 0.0, 
    -0.519779), ), ((-4.945369, 0.0, 0.519779), ), ), point1=
    mdb.models['Model-1'].parts['Surface'].InterestingPoint(
    mdb.models['Model-1'].parts['Surface'].edges.findAt((5.303301, 0.0, 
    5.303301), ), MIDDLE), point2=
    mdb.models['Model-1'].parts['Surface'].InterestingPoint(
    mdb.models['Model-1'].parts['Surface'].edges.findAt((-5.303301, 0.0, 
    -5.303301), ), MIDDLE))
mdb.models['Model-1'].parts['Surface'].setMeshControls(regions=
    mdb.models['Model-1'].parts['Surface'].faces.findAt(((0.487726, 0.0, 
    4.951963), ), ((0.487726, 0.0, -4.951963), ), ((-0.487726, 0.0, -4.951963), 
    ), ((-0.487726, 0.0, 4.951963), ), ), technique=STRUCTURED)
mdb.models['Model-1'].parts['Surface'].seedPart(deviationFactor=0.1, 
    minSizeFactor=0.1, size=MeshSize)
mdb.models['Model-1'].parts['Surface'].generateMesh()
mdb.models['Model-1'].parts['Specimen'].DatumPlaneByThreePoints(point1=
    mdb.models['Model-1'].parts['Specimen'].vertices.findAt((5.0, 15.0, 0.0), )
    , point2=mdb.models['Model-1'].parts['Specimen'].InterestingPoint(
    mdb.models['Model-1'].parts['Specimen'].edges.findAt((0.0, 15.0, 5.0), ), 
    MIDDLE), point3=mdb.models['Model-1'].parts['Specimen'].InterestingPoint(
    mdb.models['Model-1'].parts['Specimen'].edges.findAt((5.0, 11.25, 0.0), ), 
    MIDDLE))
mdb.models['Model-1'].parts['Specimen'].DatumPlaneByRotation(angle=90.0, axis=
    mdb.models['Model-1'].parts['Specimen'].datums[1], plane=
    mdb.models['Model-1'].parts['Specimen'].datums[2])
mdb.models['Model-1'].parts['Specimen'].PartitionCellByDatumPlane(cells=
    mdb.models['Model-1'].parts['Specimen'].cells.findAt(((0.307377, 0.0, 
    4.885617), )), datumPlane=
    mdb.models['Model-1'].parts['Specimen'].datums[2])
mdb.models['Model-1'].parts['Specimen'].PartitionCellByDatumPlane(cells=
    mdb.models['Model-1'].parts['Specimen'].cells.findAt(((-1.618236, 0.0, 
    0.398859), ), ((1.618236, 0.0, -0.398859), ), ), datumPlane=
    mdb.models['Model-1'].parts['Specimen'].datums[3])
mdb.models['Model-1'].parts['Specimen'].seedPart(deviationFactor=0.1, 
    minSizeFactor=0.1, size=MeshSize)
mdb.models['Model-1'].parts['Specimen'].generateMesh()

# ========================= Material Property =========================
mdb.models['Model-1'].Material(name='Aluminum')
mdb.models['Model-1'].materials['Aluminum'].Density(table=((2.7e-09, ), ))
mdb.models['Model-1'].materials['Aluminum'].Elastic(table=((69900.0, 0.33), ))
mdb.models['Model-1'].materials['Aluminum'].Plastic(hardening=JOHNSON_COOK, 
    table=((95.78, 497.05, 0.4488, 0.0, 0.0, 0.0), ))
mdb.models['Model-1'].HomogeneousSolidSection(material='Aluminum', name=
    'Aluminum', thickness=None)
mdb.models['Model-1'].parts['Specimen'].Set(cells=
    mdb.models['Model-1'].parts['Specimen'].cells.findAt(((0.370868, 0.0, 
    -3.291547), ), ((0.370868, 0.0, 3.291547), ), ((-0.370868, 0.0, 3.291547), 
    ), ((-0.370868, 0.0, -3.291547), ), ), name='Set-1')
mdb.models['Model-1'].parts['Specimen'].SectionAssignment(offset=0.0, 
    offsetField='', offsetType=MIDDLE_SURFACE, region=
    mdb.models['Model-1'].parts['Specimen'].sets['Set-1'], sectionName=
    'Aluminum', thicknessAssignment=FROM_SECTION)


# ========================= Assembly =========================
mdb.models['Model-1'].rootAssembly.DatumCsysByDefault(CARTESIAN)
mdb.models['Model-1'].rootAssembly.Instance(dependent=ON, name='Specimen-1', 
    part=mdb.models['Model-1'].parts['Specimen'])
mdb.models['Model-1'].rootAssembly.Instance(dependent=ON, name='Surface-1', 
    part=mdb.models['Model-1'].parts['Surface'])
mdb.models['Model-1'].rootAssembly.instances['Surface-1'].translate(vector=(
    14.5, 0.0, 0.0))
mdb.models['Model-1'].rootAssembly.Instance(dependent=ON, name='Surface-2', 
    part=mdb.models['Model-1'].parts['Surface'])
mdb.models['Model-1'].rootAssembly.instances['Surface-2'].translate(vector=(
    32.35, 0.0, 0.0))
mdb.models['Model-1'].rootAssembly.translate(instanceList=('Surface-1', ), 
    vector=(-14.5, 15.0, 0.0))
mdb.models['Model-1'].rootAssembly.translate(instanceList=('Surface-2', ), 
    vector=(-32.35, 0.0, 0.0))

# ========================= Step =========================
mdb.models['Model-1'].ExplicitDynamicsStep(massScaling=((SEMI_AUTOMATIC, MODEL, 
    AT_BEGINNING, 1000.0, 0.0, None, 0, 0, 0.0, 0.0, 0, None), ), name='Step-1'
    , previous='Initial')
mdb.models['Model-1'].fieldOutputRequests['F-Output-1'].setValues(numIntervals=
    50, variables=('S', 'PE', 'PEEQ', 'LE', 'U', 'V', 'RF', 'CSTRESS'))

# ========================= Interactions =========================
mdb.models['Model-1'].ContactProperty('IntProp-1')
mdb.models['Model-1'].interactionProperties['IntProp-1'].TangentialBehavior(
    dependencies=0, directionality=ISOTROPIC, elasticSlipStiffness=None, 
    formulation=PENALTY, fraction=0.005, maximumElasticSlip=FRACTION, 
    pressureDependency=OFF, shearStressLimit=None, slipRateDependency=OFF, 
    table=((0.1, ), ), temperatureDependency=OFF)
mdb.models['Model-1'].ContactExp(createStepName='Step-1', name='Int-1')
mdb.models['Model-1'].interactions['Int-1'].includedPairs.setValuesInStep(
    stepName='Step-1', useAllstar=ON)
mdb.models['Model-1'].interactions['Int-1'].contactPropertyAssignments.appendInStep(
    assignments=((GLOBAL, SELF, 'IntProp-1'), ), stepName='Step-1')
mdb.models['Model-1'].rootAssembly.Set(name='Set-1', referencePoints=(
    mdb.models['Model-1'].rootAssembly.instances['Surface-2'].referencePoints[2], 
    ))
# ========================= BCs =========================
mdb.models['Model-1'].EncastreBC(createStepName='Step-1', localCsys=None, name=
    'BottomFix', region=mdb.models['Model-1'].rootAssembly.sets['Set-1'])
mdb.models['Model-1'].boundaryConditions['BottomFix'].move('Step-1', 'Initial')
mdb.models['Model-1'].SmoothStepAmplitude(data=((0.0, 0.0), (1.0, 1.0)), name=
    'Amp-1', timeSpan=STEP)
mdb.models['Model-1'].rootAssembly.Set(name='Set-2', referencePoints=(
    mdb.models['Model-1'].rootAssembly.instances['Surface-1'].referencePoints[2], 
    ))
# Displacement
mdb.models['Model-1'].DisplacementBC(amplitude='Amp-1', createStepName='Step-1'
    , distributionType=UNIFORM, fieldName='', fixed=OFF, localCsys=None, name=
    'Top_Displacement', region=mdb.models['Model-1'].rootAssembly.sets['Set-2']
    , u1=0.0, u2=-1*DisplacementValue, u3=0.0, ur1=0.0, ur2=0.0, ur3=0.0)

# ========================= Creating and Submittion the Job =========================
mdb.Job(activateLoadBalancing=False, atTime=None, contactPrint=OFF, 
    description='', echoPrint=OFF, explicitPrecision=SINGLE, historyPrint=OFF, 
    memory=90, memoryUnits=PERCENTAGE, model='Model-1', modelPrint=OFF, 
    multiprocessingMode=DEFAULT, name='Job-1', nodalOutputPrecision=SINGLE, 
    numCpus=4, numDomains=4, parallelizationMethodExplicit=DOMAIN, queue=None, 
    scratch='', type=ANALYSIS, userSubroutine='', waitHours=0, waitMinutes=0)
# mdb.jobs['Job-1'].submit(consistencyChecking=OFF)

